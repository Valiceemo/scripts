Calculations for the position of the sun and moon.


